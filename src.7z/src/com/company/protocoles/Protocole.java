package com.company.protocoles;


/**
 * Interface pour Executer les differents Algorithme de cryptographie
 */
public interface Protocole {

    void executer();
}
